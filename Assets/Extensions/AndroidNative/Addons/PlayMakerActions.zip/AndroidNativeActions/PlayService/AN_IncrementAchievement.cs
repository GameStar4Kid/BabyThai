﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_IncrementAchievement : FsmStateAction {
		
		public FsmString achievementName;	
		public FsmInt numsteps;		
		
		public override void OnEnter() {
			GooglePlayManager.instance.IncrementAchievement (achievementName.Value, numsteps.Value);
			Finish();
		}		
	}
}
