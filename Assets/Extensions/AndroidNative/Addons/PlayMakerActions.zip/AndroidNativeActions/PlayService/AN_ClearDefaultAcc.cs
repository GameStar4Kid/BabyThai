﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - PlayService")]
	public class AN_ClearDefaultAcc : FsmStateAction {


				
		public override void OnEnter() {
			GooglePlusAPI.instance.ClearDefaultAccount();
			Finish ();
		}
	}
}
