﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("WP8 Native  - Pop-ups")]
	public class WPN_RatePopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;   

		public FsmEvent yesEvent;
		public FsmEvent noEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public WP8DialogResult ResultInEditor = WP8DialogResult.RATED;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}


			WP8RateUsPopUp rate = WP8RateUsPopUp.Create(title.Value, message.Value);

			rate.addEventListener(BaseEvent.COMPLETE, onRatePopUpClose);
			
		}

		public override void Reset() {
			base.Reset();

			title =  "Dialog title";
			message   = "Dialog message";

			
		}



		private void onRatePopUpClose(CEvent e) {
			
			//removing listner
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, onRatePopUpClose);
			
			//parsing result
			ParseResult((WP8DialogResult)e.data);
		}


		private void ParseResult(WP8DialogResult res) {
			switch(res) {
			case WP8DialogResult.RATED:
				Fsm.Event(yesEvent);
				break;
			case WP8DialogResult.DECLINED:
				Fsm.Event(noEvent);
				break;
			}
			
			Finish();
		}
		
	}
}


