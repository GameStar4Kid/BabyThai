using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("WP8 Native - Billing")]
	[Tooltip("Init billing. Best practice to do this on appplicaton start")]
	public class WPN_initBilling : FsmStateAction {


		[Tooltip("Event fired when billing initlization is complete")]
		public FsmEvent successEvent;

		public override void Reset() {
		
		}



		public override void OnEnter() {

			bool IsInEdditorMode = false;

			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif


			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			WP8InAppPurchasesManager.instance.addEventListener (WP8InAppPurchasesManager.INITIALIZED, OnInit);
			WP8InAppPurchasesManager.instance.init();


		}


		private void OnInit() {
			WP8InAppPurchasesManager.instance.removeEventListener (WP8InAppPurchasesManager.INITIALIZED, OnInit);

			Fsm.Event(successEvent);
			Finish();
		}

	}
}

